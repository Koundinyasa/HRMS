import { useMemo, useState } from "react";
import { createPortal } from "react-dom";
import { useAppSelector } from "@/hooks/useAppSelector";
import {
  Check,
  ChevronLeft,
  ChevronRight,
  ChevronsLeft,
  ChevronsRight,
  ClockFading,
  FileSpreadsheet,
  MoreVertical,
  Search,
  X as XIcon,
} from "lucide-react";
import * as XLSX from "xlsx";
import FilterDropdown, { type FilterOption } from "@/features/admin/components/FilterDropdown";

import EmptyState from "./EmptyState";
import ForceLeaveApprovalTabs from "./ForceLeaveApprovalTabs";
import ForceLeaveApprovalTable from "./ForceLeaveApprovalTable";

import type { FilterValues } from "@/features/admin/components/FilterBar";

import {
  useGetForceLeaveApprovalsQuery,
  useGetForceLeaveApprovalDropdownsQuery,
  useApproveLeavesMutation,
  useRejectLeavesMutation,
  type LeaveApprovalViewType,
  type LeaveApprovalMonthType,
} from "../api/forceleaveapprovalApi";

const toFilterOptions = (
  records: Record<string, unknown>[],
  valueKeys: string[],
  labelKeys: string[],
): FilterOption[] => records.flatMap((record) => {
  const entries = Object.entries(record);
  const findValue = (keys: string[]) => {
    for (const key of keys) {
      const normalizedKey = key.replace(/[^a-z0-9]/gi, "").toLowerCase();
      const entry = entries.find(([field]) => field.replace(/[^a-z0-9]/gi, "").toLowerCase() === normalizedKey);
      if (entry?.[1] !== undefined && entry[1] !== null && String(entry[1]).trim()) return String(entry[1]);
    }
    return undefined;
  };
  const label = findValue(labelKeys);
  // Some dropdown result sets expose only a display value (for example a
  // status name) instead of a separate ID. Keep those options selectable so
  // the panel can apply them against the corresponding row field locally.
  const value = findValue(valueKeys) ?? label;
  return value && label ? [{ value, label }] : [];
});

const toLeaveFilterOptions = (
  leaveTypes: Record<string, unknown>[],
  leaveTypeCodes: Record<string, unknown>[],
): FilterOption[] => {
  const read = (record: Record<string, unknown>, keys: string[]) => {
    const entries = Object.entries(record);
    for (const key of keys) {
      const normalizedKey = key.replace(/[^a-z0-9]/gi, "").toLowerCase();
      const match = entries.find(([field]) => field.replace(/[^a-z0-9]/gi, "").toLowerCase() === normalizedKey);
      if (match?.[1] !== undefined && match[1] !== null && String(match[1]).trim()) return String(match[1]).trim();
    }
    return undefined;
  };

  return leaveTypes.flatMap((leaveType, index) => {
    const id = read(leaveType, ["leaveTypeId", "leaveId", "id", "value"]);
    const name = read(leaveType, ["leaveTypeName", "leaveName", "name", "label"]);
    const matchingById = leaveTypeCodes.find((code) => {
      const codeId = read(code, ["leaveTypeId", "leaveId", "id", "value"]);
      return id && codeId ? id === codeId : false;
    });
    const indexedCode = leaveTypeCodes[index];
    const indexedCodeId = indexedCode && read(indexedCode, ["leaveTypeId", "leaveId", "id", "value"]);
    const matchingCode = matchingById ?? (indexedCodeId ? undefined : indexedCode);
    const code = matchingCode && read(matchingCode, [
      "leaveTypeCode",
      "leaveCode",
      "code",
      "abbreviation",
      "shortName",
      "name",
      "label",
    ]);
    const value = id ?? (matchingCode && read(matchingCode, ["leaveTypeId", "leaveId", "id", "value"]));
    const label = code ?? name;
    return value && label ? [{ value, label, aliases: name && code ? [name] : undefined }] : [];
  });
};

const getSingleSelectedId = (
  selected: string[] | string | undefined,
  options: FilterOption[] | undefined,
): number | undefined => {
  if (!Array.isArray(selected) || selected.length !== 1) return undefined;
  const value = options?.find((option) => option.value === selected[0])?.value;
  if (!value) return undefined;
  const id = Number(value);
  return Number.isSafeInteger(id) && id > 0 ? id : undefined;
};

const getSelectedIds = (selected: string[] | string | undefined, options: FilterOption[] | undefined) =>
  (Array.isArray(selected) ? selected : [])
    .map((value) => Number(options?.find((option) => option.value === value)?.value))
    .filter((id) => Number.isSafeInteger(id) && id > 0);

const normalizeFilterValue = (value: string) => value.trim().toLocaleLowerCase();

const getLeaveMatchKeys = (value: string) => {
  const normalized = normalizeFilterValue(value);
  const keys = new Set([normalized]);
  const parenthesizedCode = normalized.match(/\(([a-z0-9_-]+)\)\s*$/i);
  const leaveName = normalized.replace(/\s*\([^)]+\)\s*$/, "").trim();

  if (parenthesizedCode?.[1]) keys.add(parenthesizedCode[1].toLowerCase());
  if (leaveName && leaveName !== normalized) keys.add(leaveName);

  return [...keys];
};

const getPageNumbers = (totalPages: number, currentPage: number) => {
  if (totalPages <= 5) return Array.from({ length: totalPages }, (_, index) => index + 1);
  if (currentPage <= 2) return [1, 2, "…", totalPages] as const;
  if (currentPage >= totalPages - 1) return [1, "…", totalPages - 1, totalPages] as const;
  return [1, "…", currentPage - 1, currentPage, currentPage + 1, "…", totalPages] as const;
};

/* ============================================================
   TYPES
   ============================================================ */

/* ============================================================
   COMPONENT
   ============================================================ */

export default function ForceLeaveApprovalPanel() {
  const approverId = useAppSelector((state) => state.auth.employeeId);
  const { data: dropdownData } = useGetForceLeaveApprovalDropdownsQuery();

  /* ============================================================
     MAIN TABS
     ============================================================ */

  const [viewType, setViewType] =
    useState<LeaveApprovalViewType>("applied");

  /* ============================================================
     MONTH TABS
     ============================================================ */

  const [monthType, setMonthType] =
    useState<LeaveApprovalMonthType>("current");

  /* ============================================================
     FILTERS
     ============================================================ */

  const [filters, setFilters] =
    useState<FilterValues>({});

  /* ============================================================
     SEARCH
     ============================================================ */

  const [search, setSearch] = useState("");
  const [showFilters, setShowFilters] = useState(true);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(5);

  /* ============================================================
     MORE MENU
     ============================================================ */

  const [showMoreMenu, setShowMoreMenu] =
    useState(false);
  const [moreMenuPosition, setMoreMenuPosition] = useState<{ top: number; left: number } | null>(null);

  /* ============================================================
     SELECTION
     ============================================================ */

  const [selectedIds, setSelectedIds] =
    useState<Set<number>>(new Set());
  const [showRejectDialog, setShowRejectDialog] = useState(false);
  const [rejectionRemarks, setRejectionRemarks] = useState("");
  const [rejectError, setRejectError] = useState("");

  /* ============================================================
     API
     ============================================================ */

  const filterOptions = useMemo<Record<string, FilterOption[]>>(() => ({
    branch: toFilterOptions(dropdownData?.branches ?? [], ["branchId", "id", "value"], ["branchName", "name", "label"]),
    salaryStructure: toFilterOptions(dropdownData?.salaryStructures ?? [], ["salaryStructureId", "structureId", "id", "value", "salaryStructure", "structureName"], ["salaryStructureName", "salaryStructure", "structureName", "salaryStructureDesc", "description", "name", "label"]),
    leave: toLeaveFilterOptions(dropdownData?.leaveTypes ?? [], dropdownData?.leaveTypeCodes ?? []),
    attendance: toFilterOptions(dropdownData?.attendanceStatuses ?? [], ["attendanceStatusId", "statusId", "attendanceId", "id", "value", "attendanceStatus", "status", "code"], ["attendanceStatus", "attendanceStatusName", "statusName", "status", "attendanceName", "description", "name", "label", "code"]),
    designation: toFilterOptions(dropdownData?.designations ?? [], ["designationId", "id", "value", "designationName", "name"], ["designationName", "designation", "name", "description", "label"]),
    empStatus: toFilterOptions(dropdownData?.employeeStatuses ?? [], ["employeeStatusId", "employeeStatusID", "statusId", "id", "value", "employeeStatus", "status"], ["employeeStatus", "employeeStatusName", "statusName", "status", "description", "name", "label"]),
  }), [dropdownData]);

  const {
    data: rows,
    isFetching,
    isError: isLoadError,
    refetch,
  } = useGetForceLeaveApprovalsQuery({
    viewType,
    monthType,
    approverId: approverId ?? undefined,
    branchId: getSelectedIds(filters.branch, filterOptions.branch).length === 1
      ? getSelectedIds(filters.branch, filterOptions.branch)[0]
      : undefined,
    branchIds: getSelectedIds(filters.branch, filterOptions.branch).length > 1
      ? getSelectedIds(filters.branch, filterOptions.branch)
      : undefined,
    structureId: getSingleSelectedId(filters.salaryStructure, filterOptions.salaryStructure),
    leaveTypeId: getSingleSelectedId(filters.leave, filterOptions.leave),
    attendanceStatusId: getSingleSelectedId(filters.attendance, filterOptions.attendance),
    designationId: getSingleSelectedId(filters.designation, filterOptions.designation),
    employmentStatusId: getSingleSelectedId(filters.empStatus, filterOptions.empStatus),
  });

  const updateFilter = (key: keyof FilterValues, value: string[]) => {
    setFilters((current) => ({ ...current, [key]: value }));
    setPage(1);
    setSelectedIds(new Set());
  };

  const visibleRows = useMemo(() => {
    // The current API/SP returns applied approval rows for both tabs and does
    // not identify cancellation requests. Keep pending applied rows out of the
    // cancellation tab until cancellation-specific records are available.
    if (viewType === "cancellation") return [];

    const now = new Date();
    const currentMonth = now.getMonth();
    const currentYear = now.getFullYear();
    const searchTerm = search.trim().toLocaleLowerCase();
    const serverFilteredKeys = new Set<keyof FilterValues>(
      (["branch", "salaryStructure", "leave", "attendance", "designation", "empStatus"] as const)
        .filter((key) => key === "branch"
          ? getSelectedIds(filters.branch, filterOptions.branch).length > 0
          : getSingleSelectedId(filters[key], filterOptions[key]) !== undefined),
    );

    return (rows ?? []).filter((row) => {
      const matchesSearch = !searchTerm ||
        row.employeeName.toLocaleLowerCase().includes(searchTerm) ||
        row.employeeId.toLocaleLowerCase().includes(searchTerm);
      if (!matchesSearch) return false;

      const matchesFilter = (key: keyof FilterValues, ...rowValues: (string | undefined)[]) => {
        const selected = (filters[key] as string[] | undefined) ?? [];
        if (selected.length === 0) return true;
        // Branch selection is filtered by the database SP, including when
        // several branches are selected; do not split employees in the browser.
        if (key === "branch" && serverFilteredKeys.has(key)) return true;
        // Trust the backend only when its filtered result omits the fields
        // needed to validate this selection locally.
        if (serverFilteredKeys.has(key) && rowValues.every((value) => !value?.trim())) return true;
        const selectedLabels = filterOptions[key]
          .filter((option) => selected.includes(option.value))
          .flatMap((option) => [option.label, ...(option.aliases ?? [])])
          .flatMap((label) => key === "leave" ? getLeaveMatchKeys(label) : [normalizeFilterValue(label)]);
        const selectedValues = selected.map(normalizeFilterValue);
        const selectedKeys = new Set([...selectedValues, ...selectedLabels]);
        return rowValues.some((value) => {
          if (!value) return false;
          const rowKeys = key === "leave"
            ? getLeaveMatchKeys(value)
            : [normalizeFilterValue(value)];
          return rowKeys.some((rowKey) => selectedKeys.has(rowKey));
        });
      };

      const matchesDropdowns =
        matchesFilter("branch", row.branchId, row.branchName) &&
        matchesFilter("salaryStructure", row.salaryStructureId, row.salaryStructureName) &&
        matchesFilter("leave", row.leaveTypeId, row.leaveName, row.leaveCode, ...row.leaveFilterValues) &&
        matchesFilter("attendance", row.attendanceStatusId, row.attendanceStatus) &&
        matchesFilter("designation", row.designationId, row.designationName) &&
        matchesFilter("empStatus", row.employeeStatusId, row.employeeStatus);
      if (!matchesDropdowns) return false;

      // Current/non-current approval tabs are based on when the leave was
      // applied. Leave dates may be in a later month than the application.
      const dateText = row.date || row.fromDate;
      const iso = dateText.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);
      const dmy = dateText.match(/^(\d{1,2})[/-]([A-Za-z]{3}|\d{1,2})[/-](\d{4})$/);
      let year: number;
      let month: number;
      if (iso) {
        year = Number(iso[1]);
        month = Number(iso[2]) - 1;
      } else if (dmy) {
        year = Number(dmy[3]);
        month = /^\d+$/.test(dmy[2])
          ? Number(dmy[2]) - 1
          : new Date(`${dmy[2]} 1, ${dmy[3]}`).getMonth();
      } else {
        return monthType === "non-current";
      }
      const isCurrentMonth = month === currentMonth && year === currentYear;
      return monthType === "current" ? isCurrentMonth : !isCurrentMonth;
    });
  }, [rows, monthType, search, filters, filterOptions, viewType]);

  const totalPages = Math.max(1, Math.ceil(visibleRows.length / pageSize));
  const currentPage = Math.min(page, totalPages);
  const paginatedRows = visibleRows.slice((currentPage - 1) * pageSize, currentPage * pageSize);

  /* ============================================================
     APPROVE MUTATION
     ============================================================ */

  const [
    approveLeaves,
    {
      isLoading: isApproving,
    },
  ] = useApproveLeavesMutation();

  /* ============================================================
     REJECT MUTATION
     ============================================================ */

  const [
    rejectLeaves,
    {
      isLoading: isRejecting,
    },
  ] = useRejectLeavesMutation();

  /* ============================================================
     CLEAR FILTERS
     ============================================================ */

  const clearAllFilters = () => {
    setSearch("");
    setFilters({});
    setPage(1);
    setShowMoreMenu(false);
    setMoreMenuPosition(null);
    setSelectedIds(new Set());
  };

  /* ============================================================
     VIEW CHANGE
     ============================================================ */

  const switchView = (
    value: LeaveApprovalViewType,
  ) => {
    setViewType(value);
    setPage(1);
    setSelectedIds(new Set());
  };

  /* ============================================================
     MONTH CHANGE
     ============================================================ */

  const switchMonth = (
    value: LeaveApprovalMonthType,
  ) => {
    setMonthType(value);
    setPage(1);
    setSelectedIds(new Set());
  };

  /* ============================================================
     SEARCH CHANGE
     ============================================================ */

  const handleSearchChange = (
    value: string,
  ) => {
    setSearch(value);
    setPage(1);
    setSelectedIds(new Set());
  };

  /* ============================================================
     SELECTION
     ============================================================ */

  const handleSelectionChange = (
    ids: number[],
  ) => {
    setSelectedIds(new Set(ids));
  };

  const hasSelection =
    selectedIds.size > 0;
  const selectedRows = visibleRows.filter((row) =>
    selectedIds.has(row.id),
  );

  /* ============================================================
     APPROVE
     ============================================================ */

  const handleApprove = async () => {
    if (!hasSelection) {
      return;
    }

    try {
      await Promise.all(
        Array.from(selectedIds, (approvalId) =>
          approveLeaves({ approvalId }).unwrap(),
        ),
      );

      setSelectedIds(new Set());
    } catch (error) {
      console.error(
        "Failed to approve leave applications:",
        error,
      );
    }
  };

  /* ============================================================
     REJECT
     ============================================================ */

  const handleReject = async () => {
    const remarks = rejectionRemarks.trim();
    if (!selectedRows.length) {
      return;
    }
    if (!remarks) {
      setRejectError("Please enter a reason for rejection.");
      return;
    }

    setRejectError("");
    try {
      await Promise.all(
        selectedRows.map((row) =>
          rejectLeaves({ approvalId: row.id, remarks }).unwrap(),
        ),
      );

      setSelectedIds(new Set());
      setShowRejectDialog(false);
      setRejectionRemarks("");
    } catch (error) {
      console.error(
        "Failed to reject leave applications:",
        error,
      );
      setRejectError("Unable to reject the selected leave. Please try again.");
    }
  };

  const openRejectDialog = () => {
    const initialReason = selectedRows.length === 1
      ? selectedRows[0].reason
      : "";
    setRejectionRemarks(initialReason);
    setRejectError("");
    setShowRejectDialog(true);
  };

  /* ============================================================
     EXCEL EXPORT
     ============================================================ */

  const handleExcelDownload = () => {
    const headers = [
      "Approver Name",
      "Employee Id",
      "Employee Name",
      "Leave Type",
      "Applied Date",
      "From Date",
      "To Date",
      "No. of Days",
    ];
    const exportRows = visibleRows.map((row) => [
      row.approverName,
      row.employeeId,
      row.employeeName,
      row.leaveName,
      row.date,
      row.fromDate,
      row.toDate,
      row.noofdaysDisplay,
    ]);
    const worksheet = XLSX.utils.aoa_to_sheet([headers, ...exportRows]);

    const workbook =
      XLSX.utils.book_new();

    XLSX.utils.book_append_sheet(
      workbook,
      worksheet,
      "Leave Approval",
    );

    XLSX.writeFile(
      workbook,
      `leave-approval-${viewType}-${monthType}.xlsx`,
    );
  };

  /* ============================================================
     EMPTY MESSAGE
     ============================================================ */

  const emptyMessage =
    useMemo(
      () =>
        viewType === "applied"
          ? "No Data Found in - Leave approval"
          : "No Data Found in - Leave Cancellation",
      [viewType],
    );

  /* ============================================================
     RENDER
     ============================================================ */

  return (
    <div className="w-full bg-[#F4F6FA] font-[Urbanist]">

      {/* ======================================================
          HEADER
          ====================================================== */}

      <div className="min-w-0 overflow-x-auto rounded-[10px] border border-[#df8d7c] bg-[#fff7f5] px-3 py-3 shadow-[0_1px_3px_rgba(15,23,42,0.04)] [scrollbar-color:#c58b7f_transparent] [scrollbar-width:thin] [&::-webkit-scrollbar]:h-1.5 [&::-webkit-scrollbar-thumb]:rounded-full [&::-webkit-scrollbar-thumb]:bg-[#c58b7f] xl:overflow-x-visible sm:px-5">
        <div className="flex min-h-[48px] w-max min-w-full flex-nowrap items-center justify-between gap-3 xl:w-full">

          {/* TITLE */}

          <h3 className="inline-flex min-h-[46px] w-fit max-w-full items-center rounded-[9px] border border-[#df8d7c] bg-white px-4 py-2 text-lg font-bold leading-7 text-[#9a5547] shadow-sm sm:text-[22px]">
            Leave Approval
          </h3>

          {/* ACTIONS */}

          <div className="flex shrink-0 flex-nowrap items-center gap-1">

            {/* APPROVE */}

            <button
              type="button"
              onClick={handleApprove}
              disabled={
                !hasSelection ||
                isApproving
              }
              className={`h-12 rounded-l-lg px-5 text-[15px] font-medium ${
                hasSelection
                  ? "bg-[#16a34a] text-white hover:bg-[#15803d]"
                  : "cursor-not-allowed bg-[#E5E5E5] text-[#AAAAAA]"
              }`}
            >
              <span className="flex items-center gap-2">
                <Check size={15} />

                {isApproving
                  ? "Approving..."
                  : "Approve"}
              </span>
            </button>

            {/* REJECT */}

            <button
              type="button"
              onClick={openRejectDialog}
              disabled={
                !hasSelection ||
                isRejecting
              }
              className={`h-12 border-l border-white/50 px-5 text-[15px] font-medium ${
                hasSelection
                  ? "bg-[#EF4444] text-white hover:bg-[#DC2626]"
                  : "cursor-not-allowed bg-[#E5E5E5] text-[#AAAAAA]"
              }`}
            >
              <span className="flex items-center gap-2">
                <XIcon size={15} />

                {isRejecting
                  ? "Rejecting..."
                  : "Reject"}
              </span>
            </button>

            {/* EXCEL */}

            <button
              type="button"
              onClick={
                handleExcelDownload
              }
              title="Download Excel"
              className="ml-4 flex h-10 w-10 items-center justify-center text-[#378B35] transition hover:scale-105"
            >
              <FileSpreadsheet
                size={23}
                strokeWidth={2}
              />
            </button>

            {/* HISTORY */}

            <button
              type="button"
              title="History"
              className="ml-2 flex h-10 w-10 items-center justify-center text-[#a45a4a] transition hover:text-[#914f3f]"
            >
              <ClockFading
                size={22}
                strokeWidth={2}
              />
            </button>

          </div>
        </div>
      </div>

      {/* ======================================================
          APPLIED LEAVE / LEAVE CANCELLATION
          ====================================================== */}

      <div className="mt-3 rounded-xl border border-slate-200 bg-white px-4 py-3 shadow-sm">
        <ForceLeaveApprovalTabs
          activeTab={viewType}
          onTabChange={switchView}
        />
      </div>

      {/* ======================================================
          CURRENT / NON-CURRENT MONTH
          ====================================================== */}

      <div className="grid w-full grid-cols-2 items-center gap-2 py-4 sm:flex sm:flex-wrap sm:gap-2 sm:py-5">

        {/* CURRENT MONTH */}

        <button
          type="button"
          onClick={() =>
            switchMonth("current")
          }
          className={`min-w-0 rounded-full px-2 py-2 text-center text-xs font-medium transition sm:px-4 sm:text-[15px] ${
            monthType === "current"
              ? "bg-[#914f3f] text-white"
              : "bg-[#E1E3E7] text-[#172033] hover:bg-[#f8e4df] hover:text-[#9a5547]"
          }`}
        >
          Current Month Details
        </button>

        {/* NON-CURRENT MONTH */}

        <button
          type="button"
          onClick={() =>
            switchMonth(
              "non-current",
            )
          }
          className={`min-w-0 rounded-full px-2 py-2 text-center text-xs font-medium transition sm:px-4 sm:text-[15px] ${
            monthType === "non-current"
              ? "bg-[#914f3f] text-white"
              : "bg-[#E1E3E7] text-[#172033] hover:bg-[#f8e4df] hover:text-[#9a5547]"
          }`}
        >
          Non-Current Month Details
        </button>

      </div>

      {/* ======================================================
          FILTER BAR
          ====================================================== */}

      <div className={`relative min-w-0 overflow-visible rounded-xl border border-slate-200 bg-white px-3 py-2 shadow-sm ${showFilters ? "" : "hidden"}`}>

        <div className="min-w-0 font-[Urbanist]">
        <div className="-mx-1 overflow-x-auto overflow-y-visible px-1 pb-2 [scrollbar-color:#c58b7f_#f1f5f9] [scrollbar-width:thin] [&::-webkit-scrollbar]:h-2 [&::-webkit-scrollbar-thumb]:rounded-full [&::-webkit-scrollbar-thumb]:bg-[#c58b7f] [&::-webkit-scrollbar-track]:rounded-full [&::-webkit-scrollbar-track]:bg-slate-100 xl:overflow-x-visible">
        <div className="flex min-h-[40px] w-max min-w-full flex-nowrap items-center gap-1.5 xl:w-full">

          {/* ==================================================
              SEARCH
              ================================================== */}

          <div className="flex h-8 w-[220px] min-w-[170px] shrink items-center rounded-lg border border-transparent bg-slate-100 px-3 transition-colors focus-within:border-indigo-200 focus-within:bg-white focus-within:ring-2 focus-within:ring-indigo-50">

            <Search
              size={16}
              strokeWidth={1.8}
              className="mr-2 shrink-0 text-[#8FA0C2]"
            />

            <input
              type="text"
              value={search}
              onChange={(event) =>
                handleSearchChange(
                  event.target.value,
                )
              }
              placeholder="Start Typing..."
              className="
                min-w-0 w-full
                border-0
                bg-transparent
                text-[13px]
                font-medium
                text-[#27364F]
                outline-none
                placeholder:text-[#C8CFDA]
              "
            />

          </div>

          {([
            ["branch", "Branch"],
            ["salaryStructure", "Salary Structure"],
            ["leave", "Leave"],
            ["attendance", "Attendance"],
            ["designation", "Designation"],
            ["empStatus", "Emp Status"],
          ] as const).map(([key, label]) => (
            <FilterDropdown
              key={key}
              label={label}
              options={filterOptions[key]}
              selected={(filters[key] as string[]) ?? []}
              onChange={(value) => updateFilter(key, value)}
              variant="chip"
              portal
              compact
            />
          ))}

          {/* ==================================================
              MORE
              ================================================== */}

          <div className="ml-auto flex shrink-0 items-center gap-1">

          <div className="relative shrink-0">

            <button
              type="button"
              aria-label="More"
              onClick={(event) => {
                if (showMoreMenu) {
                  setShowMoreMenu(false);
                  setMoreMenuPosition(null);
                  return;
                }
                const rect = event.currentTarget.getBoundingClientRect();
                setMoreMenuPosition({
                  top: Math.min(rect.bottom + 8, Math.max(8, window.innerHeight - 100)),
                  left: Math.max(8, Math.min(rect.right - 168, window.innerWidth - 168)),
                });
                setShowMoreMenu(true);
              }}
              className="
                flex
                h-7
                w-7
                items-center
                justify-center
                text-[#91A1C4]
              "
            >
                <MoreVertical
                  size={17}
              />
            </button>

            {showMoreMenu && moreMenuPosition && createPortal(
              <div style={{ top: moreMenuPosition.top, left: moreMenuPosition.left }} className="fixed z-[100] w-[160px] rounded-lg border border-slate-200 bg-white p-2 shadow-lg">

                <span className="block px-3 py-2 text-[13px] text-slate-400">
                  More filters
                </span>

              </div>,
              document.body,
            )}

          </div>

          {/* ==================================================
              CLEAR
              ================================================== */}

          <button
            type="button"
            aria-label="Close filters"
            title="Close filters"
            onClick={() => {
              clearAllFilters();
              setShowFilters(false);
            }}
            className="
              flex
              h-7
              w-7
              shrink-0
              cursor-pointer
              items-center
              justify-center
              text-red-500
              transition
              hover:text-red-600
            "
          >
            <XIcon size={17} />
          </button>

          </div>

        </div>

        </div>
        </div>
      </div>

      {/* ======================================================
          TABLE / EMPTY STATE
          ====================================================== */}

      <div className="mt-4 min-w-0 rounded-xl border border-slate-200 bg-white px-2 py-3 shadow-sm sm:px-4 sm:py-4">

        {isLoadError ? (
          <div
            role="alert"
            className="flex min-h-[180px] flex-col items-center justify-center gap-3 text-center text-sm text-red-600"
          >
            <span>Unable to load leave approvals from the server.</span>
            <button
              type="button"
              onClick={() => void refetch()}
              className="rounded-md border border-red-300 px-3 py-1.5 font-medium hover:bg-red-50"
            >
              Retry
            </button>
          </div>
        ) : isFetching ? (

          <div className="flex min-h-[300px] items-center justify-center">

            <span className="text-[14px] text-slate-400">
              Loading...
            </span>

          </div>

        ) : (

          <>
            <ForceLeaveApprovalTable
              rows={paginatedRows}
              selectedIds={Array.from(
                selectedIds,
              )}
              onSelectionChange={
                handleSelectionChange
              }
              loading={false}
            />

            {visibleRows.length === 0 && (
              <div className="pt-5">

                <EmptyState
                  message={
                    emptyMessage
                  }
                />

              </div>
            )}

            {visibleRows.length > 0 && (
              <div className="mt-3 flex flex-wrap items-center justify-between gap-x-4 gap-y-2 border-t border-slate-200 px-2 pt-3 font-[Urbanist] text-[12px] text-slate-500">
                <div className="flex flex-wrap items-center gap-1.5">
                  <span className="mr-1">Rows per page</span>
                  {[5, 10, 25, 50, 100].map((size) => (
                    <button
                      key={size}
                      type="button"
                      onClick={() => {
                        setPageSize(size);
                        setPage(1);
                      }}
                      aria-pressed={pageSize === size}
                      className={`min-w-8 rounded-md px-2 py-1 font-semibold transition-colors ${
                        pageSize === size
                          ? "bg-[#914f3f] text-white shadow-sm"
                          : "bg-slate-100 text-slate-600 hover:bg-slate-200"
                      }`}
                    >
                      {size}
                    </button>
                  ))}
                  <span className="ml-2 whitespace-nowrap">
                    {(currentPage - 1) * pageSize + 1} to {Math.min(currentPage * pageSize, visibleRows.length)} of {visibleRows.length}
                  </span>
                </div>

                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => setPage(1)}
                    disabled={currentPage === 1}
                    aria-label="First page"
                    className="flex h-7 w-7 items-center justify-center rounded text-slate-500 hover:bg-slate-100 disabled:cursor-not-allowed disabled:opacity-40"
                  >
                    <ChevronsLeft size={15} />
                  </button>
                  <button
                    type="button"
                    onClick={() => setPage((current) => Math.max(1, current - 1))}
                    disabled={currentPage === 1}
                    aria-label="Previous page"
                    className="flex h-7 w-7 items-center justify-center rounded text-slate-500 hover:bg-slate-100 disabled:cursor-not-allowed disabled:opacity-40"
                  >
                    <ChevronLeft size={15} />
                  </button>

                  {getPageNumbers(totalPages, currentPage).map((pageNumber, index) =>
                    typeof pageNumber === "number" ? (
                      <button
                        key={`${pageNumber}-${index}`}
                        type="button"
                        onClick={() => setPage(pageNumber)}
                        aria-current={currentPage === pageNumber ? "page" : undefined}
                        className={`h-7 min-w-7 rounded px-2 font-semibold ${
                          currentPage === pageNumber
                            ? "bg-[#914f3f] text-white shadow-sm"
                            : "text-slate-600 hover:bg-slate-100"
                        }`}
                      >
                        {pageNumber}
                      </button>
                    ) : (
                      <span key={`ellipsis-${index}`} className="px-1 text-slate-400">{pageNumber}</span>
                    ),
                  )}

                  <button
                    type="button"
                    onClick={() => setPage((current) => Math.min(totalPages, current + 1))}
                    disabled={currentPage === totalPages}
                    aria-label="Next page"
                    className="flex h-7 w-7 items-center justify-center rounded text-slate-500 hover:bg-slate-100 disabled:cursor-not-allowed disabled:opacity-40"
                  >
                    <ChevronRight size={15} />
                  </button>
                  <button
                    type="button"
                    onClick={() => setPage(totalPages)}
                    disabled={currentPage === totalPages}
                    aria-label="Last page"
                    className="flex h-7 w-7 items-center justify-center rounded text-slate-500 hover:bg-slate-100 disabled:cursor-not-allowed disabled:opacity-40"
                  >
                    <ChevronsRight size={15} />
                  </button>
                </div>
              </div>
            )}
          </>
        )}

      </div>

      {showRejectDialog && createPortal(
        <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-slate-900/40 p-4">
          <section
            role="dialog"
            aria-modal="true"
            aria-labelledby="force-reject-leave-title"
            className="max-h-[calc(100vh-2rem)] w-full max-w-[640px] overflow-y-auto rounded-xl bg-white p-5 shadow-2xl sm:p-6"
          >
            <div className="flex items-start justify-between gap-4">
              <div>
                <h2 id="force-reject-leave-title" className="text-lg font-semibold text-slate-900">
                  Reject Leave
                </h2>
                <p className="mt-1 text-sm text-slate-600">
                  Please review the leave details before rejecting this leave.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setShowRejectDialog(false)}
                disabled={isRejecting}
                aria-label="Close rejection dialog"
                className="text-slate-900 hover:text-slate-500 disabled:opacity-50"
              >
                <XIcon size={20} />
              </button>
            </div>

            {selectedRows.length === 1 ? (
              <div className="mt-5 grid gap-3 sm:grid-cols-2">
                {[
                  ["Leave Type", selectedRows[0].leaveName],
                  ["Leave ID", String(selectedRows[0].id)],
                  ["Employee Name", selectedRows[0].employeeName],
                  ["Applied Date", selectedRows[0].date],
                  ["From Date", selectedRows[0].fromDate],
                  ["To Date", selectedRows[0].toDate],
                ].map(([label, value]) => (
                  <div key={label}>
                    <p className="mb-1 text-sm font-medium text-slate-800">{label}</p>
                    <div className="rounded-md border border-slate-900/80 bg-slate-50 px-3 py-3 text-sm text-slate-800">
                      {value || "-"}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="mt-5 max-h-44 overflow-y-auto rounded-md border border-slate-200">
                {selectedRows.map((row) => (
                  <div key={row.id} className="grid grid-cols-[auto_1fr] gap-x-3 border-b border-slate-100 px-3 py-2 text-sm last:border-b-0">
                    <span className="font-medium text-slate-800">{row.employeeName}</span>
                    <span className="text-right text-slate-600">{row.leaveName} · {row.fromDate} – {row.toDate} · ID {row.id}</span>
                  </div>
                ))}
              </div>
            )}

            <label htmlFor="force-rejection-remarks" className="mt-5 block text-sm font-medium text-slate-800">
              Remarks
            </label>
            <textarea
              id="force-rejection-remarks"
              value={rejectionRemarks}
              onChange={(event) => {
                setRejectionRemarks(event.target.value);
                setRejectError("");
              }}
              disabled={isRejecting}
              rows={5}
              placeholder="Enter rejection remarks..."
              className="mt-1 w-full resize-none rounded-md border border-slate-900/80 px-3 py-3 text-sm text-slate-700 outline-none focus:border-sky-500 focus:ring-2 focus:ring-sky-100 disabled:bg-slate-100"
            />

            {rejectError && (
              <p role="alert" className="mt-2 text-sm text-red-600">
                {rejectError}
              </p>
            )}

            <div className="mt-6 flex justify-end gap-2 border-t border-slate-400 pt-5">
              <button
                type="button"
                onClick={() => setShowRejectDialog(false)}
                disabled={isRejecting}
                className="rounded-md border border-slate-900 px-5 py-2.5 text-sm font-medium text-slate-900 hover:bg-slate-50 disabled:opacity-50"
              >
                Close
              </button>
              <button
                type="button"
                onClick={() => void handleReject()}
                disabled={isRejecting}
                className="rounded-md bg-violet-400 px-5 py-2.5 text-sm font-semibold text-white hover:bg-violet-500 disabled:cursor-not-allowed disabled:opacity-50"
              >
                {isRejecting ? "Submitting..." : "Submit"}
              </button>
            </div>
          </section>
        </div>,
        document.body,
      )}

    </div>
  );
}
