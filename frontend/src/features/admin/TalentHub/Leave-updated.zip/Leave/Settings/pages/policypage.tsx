// import { useState } from "react";
// import { useNavigate, useParams } from "react-router-dom";
// import {Plus,Settings as SettingsIcon,Trash2,Pencil,History,DollarSign,Sun,CirclePlus,Star,Heart} from "lucide-react";
// import {useGetLeavePoliciesQuery,useGetPolicyLeavesQuery,useDeleteLeavePolicyMutation,useRemoveLeaveFromPolicyMutation} from "../api/settingsApi";
// import type { LeaveIconKey } from "../types/leavesettings.types";
// import AddLeavePolicyModal from "../components/addleavepolicymodal";
// import AddLeaveTypeModal from "../components/addleavetypemodal";

// const ICONS: Record<LeaveIconKey, React.ComponentType<{ size?: number }>> = {
//   lop: DollarSign,
//   cl: Sun,
//   sl: CirclePlus,
//   rh: Star,
//   ml: Heart,
// };

// export default function PolicyPage() {
//   const navigate = useNavigate();
//   const { domain } = useParams();

//   const { data: policies = [], isLoading: policiesLoading } = useGetLeavePoliciesQuery();
//   const [selectedPolicyId, setSelectedPolicyId] = useState<number | null>(null);
//   const activePolicyId = selectedPolicyId ?? policies[0]?.policyId ?? null;

//   const { data: leaves = [], isLoading: leavesLoading } = useGetPolicyLeavesQuery(
//     activePolicyId as number,
//     { skip: activePolicyId === null }
//   );

//   const [deletePolicy] = useDeleteLeavePolicyMutation();
//   const [removeLeave] = useRemoveLeaveFromPolicyMutation();

//   const [policyModalOpen, setPolicyModalOpen] = useState(false);
//   const [editingPolicyId, setEditingPolicyId] = useState<number | null>(null);
//   const [leaveTypeModalOpen, setLeaveTypeModalOpen] = useState(false);

//   const handleDeletePolicy = async (policyId: number) => {
//     if (!confirm("Delete this leave policy?")) return;
//     await deletePolicy(policyId);
//     if (activePolicyId === policyId) setSelectedPolicyId(null);
//   };

//   const handleDeleteLeave = async (leaveId: number) => {
//     if (!activePolicyId) return;
//     if (!confirm("Remove this leave type from the policy?")) return;
//     await removeLeave({ policyId: activePolicyId, leaveId });
//   };

//   const openLeaveSettings = (leaveId: number) => {
//     if (!activePolicyId) return;
//     navigate(
//       `/${domain}/admin/time-office/leave/settings/policy/${activePolicyId}/leave/${leaveId}/behavior`
//     );
//   };

//   return (
//     <div className="grid w-full min-w-0 grid-cols-1 gap-4 lg:grid-cols-[260px_minmax(0,1fr)]">
//       {/* Policy list */}
//       <div className="bg-white rounded-xl border border-slate-100 shadow-sm p-4">
//         <div className="flex items-center justify-between mb-3">
//           <h3 className="text-sm font-semibold text-slate-800">Leave Policy</h3>
//           <button
//             type="button"
//             onClick={() => {
//               setEditingPolicyId(null);
//               setPolicyModalOpen(true);
//             }}
//             className="flex items-center justify-center w-7 h-7 rounded-lg border border-emerald-500 text-emerald-600 hover:bg-emerald-50 transition-colors"
//           >
//             <Plus size={14} />
//           </button>
//         </div>

//         <div className="flex flex-col gap-2">
//           {policiesLoading ? (
//             <p className="text-xs text-slate-400">Loading...</p>
//           ) : (
//             policies.map((policy) => (
//               <div
//                 key={policy.policyId}
//                 onClick={() => setSelectedPolicyId(policy.policyId)}
//                 className={`flex items-center justify-between gap-2 px-3 py-2.5 rounded-lg border cursor-pointer transition-colors ${
//                   policy.policyId === activePolicyId
//                     ? "border-slate-200 bg-slate-50"
//                     : "border-transparent hover:bg-slate-50"
//                 }`}
//               >
//                 <div className="flex items-center gap-2 min-w-0">
//                   <span className="flex items-center justify-center w-6 h-6 rounded-md bg-blue-100 text-blue-600 text-xs font-semibold shrink-0">
//                     {policy.shortLabel}
//                   </span>
//                   <span className="text-sm font-medium text-sky-600 truncate">{policy.name}</span>
//                 </div>
//                 <div className="flex items-center gap-1 shrink-0">
//                   <button
//                     type="button"
//                     onClick={(e) => {
//                       e.stopPropagation();
//                       setEditingPolicyId(policy.policyId);
//                       setPolicyModalOpen(true);
//                     }}
//                     className="text-slate-400 hover:text-slate-600"
//                   >
//                     <Pencil size={13} />
//                   </button>
//                   <button
//                     type="button"
//                     onClick={(e) => {
//                       e.stopPropagation();
//                       handleDeletePolicy(policy.policyId);
//                     }}
//                     className="text-red-400 hover:text-red-600"
//                   >
//                     <Trash2 size={13} />
//                   </button>
//                 </div>
//               </div>
//             ))
//           )}
//         </div>
//       </div>

//       {/* Leave types table */}
//       <div className="min-w-0 overflow-hidden rounded-xl border border-slate-100 bg-white p-3 shadow-sm sm:p-5">
//         <div className="mb-4 flex flex-wrap items-center justify-end gap-2">
//           <button
//             type="button"
//             onClick={() => setLeaveTypeModalOpen(true)}
//             disabled={!activePolicyId}
//             className="flex min-h-9 max-w-full items-center justify-center gap-1.5 rounded-lg border border-emerald-500 px-3 py-2 text-left text-xs font-medium text-emerald-600 transition-colors hover:bg-emerald-50 disabled:opacity-50 sm:text-sm"
//           >
//             <Plus size={14} />
//             Add Leaves To Employee Leave Policy
//           </button>
//           <button
//             type="button"
//             title="History"
//             className="flex items-center justify-center h-9 w-9 rounded-lg border border-slate-200 text-slate-400 hover:bg-slate-50 transition-colors"
//           >
//             <History size={15} />
//           </button>
//         </div>

//         <div className="w-full overflow-x-auto">
//         <table className="w-full min-w-[520px] text-sm">
//           <thead>
//             <tr className="text-left text-slate-500 border-b border-slate-100">
//               <th className="font-medium pb-3">Leave Name</th>
//               <th className="font-medium pb-3">Short Name</th>
//               <th className="font-medium pb-3">Active</th>
//               <th className="font-medium pb-3 text-right">Action</th>
//             </tr>
//           </thead>
//           <tbody>
//             {leavesLoading ? (
//               <tr>
//                 <td colSpan={4} className="text-center py-8 text-slate-400">
//                   Loading...
//                 </td>
//               </tr>
//             ) : leaves.length === 0 ? (
//               <tr>
//                 <td colSpan={4} className="text-center py-8 text-slate-400">
//                   No leave types added to this policy yet.
//                 </td>
//               </tr>
//             ) : (
//               leaves.map((leave) => {
//                 const Icon = ICONS[leave.icon] ?? DollarSign;
//                 return (
//                   <tr key={leave.leaveId} className="border-b border-slate-50">
//                     <td className="py-3">
//                       <span className="flex items-center gap-2">
//                         <span className="flex items-center justify-center w-6 h-6 rounded-full bg-emerald-100 text-emerald-600">
//                           <Icon size={13} />
//                         </span>
//                         <span className="text-slate-700">{leave.leaveName}</span>
//                       </span>
//                     </td>
//                     <td className="py-3">
//                       <span className="px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 text-xs font-medium">
//                         {leave.shortName}
//                       </span>
//                     </td>
//                     <td className="py-3">
//                       <span
//                         className={`px-2.5 py-1 rounded-md text-xs font-semibold ${
//                           leave.active ? "bg-emerald-500 text-white" : "bg-red-500 text-white"
//                         }`}
//                       >
//                         {leave.active ? "True" : "False"}
//                       </span>
//                     </td>
//                     <td className="py-3 text-right">
//                       <span className="flex items-center justify-end gap-2">
//                         <button
//                           type="button"
//                           onClick={() => openLeaveSettings(leave.leaveId)}
//                           className="text-slate-400 hover:text-slate-600"
//                         >
//                           <SettingsIcon size={15} />
//                         </button>
//                         <button
//                           type="button"
//                           onClick={() => handleDeleteLeave(leave.leaveId)}
//                           className="text-red-400 hover:text-red-600"
//                         >
//                           <Trash2 size={15} />
//                         </button>
//                       </span>
//                     </td>
//                   </tr>
//                 );
//               })
//             )}
//           </tbody>
//         </table>
//         </div>
//       </div>

//       {policyModalOpen && (
//         <AddLeavePolicyModal
//           policyId={editingPolicyId}
//           onClose={() => setPolicyModalOpen(false)}
//         />
//       )}

//       {leaveTypeModalOpen && activePolicyId && (
//         <AddLeaveTypeModal
//           policyId={activePolicyId}
//           onClose={() => setLeaveTypeModalOpen(false)}
//         />
//       )}
//     </div>
//   );
// }


import { useCallback, useEffect, useState } from "react";
import { useNavigate, useOutletContext, useParams } from "react-router-dom";

import {
  DollarSign,
  Sun,
  CirclePlus,
  Star,
  Heart,
  Plus,
  ClockFading,
} from "lucide-react";

import {
  useGetLeavePoliciesQuery,
  useGetPolicyLeavesQuery,
  useDeleteLeavePolicyMutation,
  useRemoveLeaveFromPolicyMutation,
} from "../api/settingsApi";

import type { LeaveIconKey } from "../types/leavesettings.types";

import PolicySidebar from "../components/PolicySidebar";
import PolicyContent from "../components/PolicyContent";
import type { LeaveSettingsOutletContext } from "./leavesettingspage";

import AddLeavePolicyModal from "../components/AddLeavePolicyModal";
import AddLeaveTypeModal from "../components/AddLeaveTypeModal";
import { useGetClassificationLeaveTypesQuery } from "@/features/admin/admincenter/classifications/api/leaveApi";

const ICONS: Record<
  LeaveIconKey,
  React.ComponentType<{
    size?: number;
    strokeWidth?: number;
  }>
> = {
  lop: DollarSign,
  cl: Sun,
  sl: CirclePlus,
  rh: Star,
  ml: Heart,
};

export default function PolicyPage() {
  const navigate = useNavigate();
  const { domain } = useParams();
  const { setHeaderActions } = useOutletContext<LeaveSettingsOutletContext>();

  /* =====================================================
     POLICIES
     ===================================================== */

  const {
    data: policies = [],
    isLoading: policiesLoading,
  } = useGetLeavePoliciesQuery();

  const [
    selectedPolicyId,
    setSelectedPolicyId,
  ] = useState<number | null>(null);

  const activePolicyId =
    selectedPolicyId ??
    policies[0]?.policyId ??
    null;

  const activePolicy = policies.find(
    (policy) =>
      policy.policyId === activePolicyId,
  );

  /* =====================================================
     LEAVES
     ===================================================== */

  const {
    data: leaves = [],
  } = useGetPolicyLeavesQuery(
    activePolicyId as number,
    {
      skip: activePolicyId === null,
    },
  );

  const { data: availableLeaveTypes = [] } = useGetClassificationLeaveTypesQuery();

  /* =====================================================
     MUTATIONS
     ===================================================== */

  const [
    deleteLeavePolicy,
  ] = useDeleteLeavePolicyMutation();

  const [
    removeLeaveFromPolicy,
  ] = useRemoveLeaveFromPolicyMutation();

  /* =====================================================
     MODAL STATE
     ===================================================== */

  const [
    policyModalOpen,
    setPolicyModalOpen,
  ] = useState(false);

  const [
    editingPolicyId,
    setEditingPolicyId,
  ] = useState<number | null>(null);

  const [
    leaveTypeModalOpen,
    setLeaveTypeModalOpen,
  ] = useState(false);

  /* =====================================================
     ADD POLICY
     ===================================================== */

  const handleAddPolicy = () => {
    setEditingPolicyId(null);
    setPolicyModalOpen(true);
  };

  /* =====================================================
     EDIT POLICY
     ===================================================== */

  const handleEditPolicy = (
    policyId: number,
  ) => {
    setEditingPolicyId(policyId);
    setPolicyModalOpen(true);
  };

  /* =====================================================
     DELETE POLICY
     ===================================================== */

  const handleDeletePolicy = async (
    policyId: number,
  ) => {
    if (
      !window.confirm(
        "Delete this leave policy?",
      )
    ) {
      return;
    }

    try {
      await deleteLeavePolicy(
        policyId,
      ).unwrap();

      if (
        activePolicyId === policyId
      ) {
        setSelectedPolicyId(null);
      }
    } catch (error) {
      console.error(
        "Failed to delete leave policy:",
        error,
      );
    }
  };

  /* =====================================================
     DELETE LEAVE FROM POLICY
     ===================================================== */

  const handleDeleteLeave = async (
    leaveId: number,
  ) => {
    if (
      activePolicyId === null
    ) {
      return;
    }

    if (
      !window.confirm(
        "Remove this leave type from the policy?",
      )
    ) {
      return;
    }

    try {
      await removeLeaveFromPolicy({
        policyId: activePolicyId,
        leaveId,
      }).unwrap();
    } catch (error) {
      console.error(
        "Failed to remove leave from policy:",
        error,
      );
    }
  };

  /* =====================================================
     OPEN LEAVE BEHAVIOUR
     ===================================================== */

  const handleLeaveSettings = (
    leaveId: number,
  ) => {
    if (
      activePolicyId === null
    ) {
      return;
    }

    navigate(
      `/${domain}/admin/time-office/leave/settings/policy/${activePolicyId}/leave/${leaveId}/behavior`,
    );
  };

  /* =====================================================
     ADD LEAVE TYPE
     ===================================================== */

  const handleAddLeave = useCallback(() => {
    setEditingPolicyId(null);
    setPolicyModalOpen(true);
  }, []);

  useEffect(() => {
    setHeaderActions(
      <div className="flex shrink-0 items-center gap-[17px]">
        <button
          type="button"
          onClick={handleAddLeave}
          className="flex h-[34px] items-center gap-[7px] rounded-[5px] border border-[#00A86B] bg-white px-[13px] font-urbanist text-[12px] font-semibold text-[#00A86B] transition-colors duration-150 hover:bg-[#F1FBF6] disabled:cursor-default disabled:opacity-60"
        >
          <Plus size={15} strokeWidth={2} />
          <span className="whitespace-nowrap">
            Add Leaves To {activePolicy?.name ?? "Employee Leave Policy"}
          </span>
        </button>
        <button
          type="button"
          title="History"
          onClick={() => {
            // History functionality will be connected when the backend/API is available.
          }}
          className="flex h-[30px] w-[30px] shrink-0 items-center justify-center text-[#172033] transition-colors hover:text-[#00A86B]"
        >
          <ClockFading size={19} strokeWidth={1.8} />
        </button>
      </div>,
    );

    return () => setHeaderActions(null);
  }, [activePolicy?.name, handleAddLeave, setHeaderActions]);

  /* =====================================================
     LOADING
     ===================================================== */

  if (policiesLoading) {
    return (
      <div className="flex min-h-[500px] w-full items-center justify-center bg-[#F8FAFC]">
        <span className="font-urbanist text-[13px] text-[#667085]">
          Loading leave policies...
        </span>
      </div>
    );
  }

  /* =====================================================
     PAGE
     ===================================================== */

  return (
    <>
      <div className="w-full min-w-0 bg-[#F8FAFC]">

        {/* =================================================
            POLICY CONTENT
           ================================================= */}

        <div className="mx-[20px] mt-[14px] flex min-h-[620px] overflow-hidden rounded-[10px] border border-[#E1E5EA] bg-white">

          {/* =================================================
              LEFT POLICY SIDEBAR
             ================================================= */}

          <PolicySidebar
            policies={policies}
            activePolicyId={
              activePolicyId
            }
            onPolicySelect={
              setSelectedPolicyId
            }
            onAddPolicy={
              handleAddPolicy
            }
            onEditPolicy={
              handleEditPolicy
            }
            onDeletePolicy={
              handleDeletePolicy
            }
          />

          {/* =================================================
              RIGHT POLICY CONTENT
             ================================================= */}

          <div className="min-w-0 flex-1 bg-[#F8FAFC]">

            <PolicyContent
              policyName={
                activePolicy?.name ??
                "Employee Leave Policy"
              }
              activePolicyId={
                activePolicyId
              }
              leaves={leaves.map(
                (leave) => ({
                  leaveId:
                    leave.leaveId,

                  leaveName:
                    leave.leaveName,

                  shortName:
                    leave.shortName,

                  active:
                    leave.active,

                  icon:
                    ICONS[
                      leave.icon
                    ] ?? DollarSign,
                }),
              )}
              onAddLeave={
                handleAddLeave
              }
              onHistory={() => {
                // History API will be connected
                // once backend provides it.
              }}
              onConfigureLeave={
                handleLeaveSettings
              }
              onDeleteLeave={
                handleDeleteLeave
              }
            />

          </div>
        </div>
      </div>

      {/* =====================================================
          ADD / EDIT LEAVE POLICY MODAL
         ===================================================== */}

      {policyModalOpen && (
        <AddLeavePolicyModal
          policyId={
            editingPolicyId
          }
          onClose={() => {
            setPolicyModalOpen(
              false,
            );

            setEditingPolicyId(
              null,
            );
          }}
        />
      )}

      {/* =====================================================
          ADD LEAVE TYPE MODAL
         ===================================================== */}

      {leaveTypeModalOpen &&
        activePolicyId !== null && (
          <AddLeaveTypeModal
            policyId={
              activePolicyId
            }
            leaveTypes={availableLeaveTypes.map((type) => ({
              id: type.leaveTypeId,
              name: type.name,
              code: type.code,
            }))}
            onClose={() => {
              setLeaveTypeModalOpen(
                false,
              );
            }}
          />
        )}
    </>
  );
}
