import { InterviewerFeedbackWorkspace } from "@/features/admin/TalentHub/components/InterviewerFeedbackWorkspace";

export default function EmployeeRecruitmentPage() {
  return <InterviewerFeedbackWorkspace />;
}
